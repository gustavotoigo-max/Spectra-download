// SpectraCast — botão flutuante nas páginas do YouTube.
// Aparece em vídeos (/watch, /shorts) e playlists (/playlist).
// - Clique no botão redondo: copia o link, pausa o vídeo desta aba e põe a música na sala.
// - Arraste o botão para qualquer lugar da aba (a posição fica salva).
// - Passando o mouse aparecem dois botões pequenos: playlists (salvar numa playlist sua) e esconder.
;(() => {
  if (window.__spectracastButton) return
  window.__spectracastButton = true

  const POS_KEY = 'spectracast.fabPos' // { x, y } em fração da janela (centro do botão)
  const SIZE = 48 // diâmetro do botão
  const MARGIN = 10 // distância mínima das bordas
  const DRAG_THRESHOLD = 5 // px antes de virar arrasto (abaixo disso é clique)

  /** O que está aberto nesta aba: vídeo, short ou playlist. */
  function currentTarget() {
    const u = new URL(location.href)
    const title = readTitle()
    if (u.pathname === '/watch' && /^[\w-]{11}$/.test(u.searchParams.get('v') || '')) {
      const v = u.searchParams.get('v')
      const list = u.searchParams.get('list')
      // Manda o vídeo; no site dá para adicionar a playlist inteira depois.
      const url = `https://www.youtube.com/watch?v=${v}` + (list ? `&list=${list}` : '')
      return { kind: 'video', url, title, id: v }
    }
    const shorts = u.pathname.match(/^\/shorts\/([\w-]{11})/)
    if (shorts) return { kind: 'video', url: `https://www.youtube.com/shorts/${shorts[1]}`, title, id: shorts[1] }
    if (u.pathname === '/playlist' && u.searchParams.get('list')) {
      const list = u.searchParams.get('list')
      return { kind: 'playlist', url: `https://www.youtube.com/playlist?list=${list}`, title, id: list }
    }
    return null
  }

  function readTitle() {
    const el =
      document.querySelector('ytd-watch-metadata h1 yt-formatted-string') ||
      document.querySelector('h1.ytd-watch-metadata') ||
      document.querySelector('ytd-reel-video-renderer[is-active] h2') ||
      document.querySelector('yt-formatted-string.title.ytmusic-player-bar')
    const t = (el && el.textContent && el.textContent.trim()) || document.title.replace(/\s*-\s*YouTube( Music)?$/, '')
    return t.replace(/^\(\d+\)\s*/, '').slice(0, 200)
  }

  // ---- interface (Shadow DOM: o CSS do YouTube não interfere) -----------------

  const SYMBOL = `
    <svg class="logo" viewBox="40 40 432 432" aria-hidden="true">
      <defs><linearGradient id="scg" gradientUnits="userSpaceOnUse" x1="70" y1="110" x2="450" y2="430">
        <stop offset="0" stop-color="#9B4DF5"/><stop offset=".3" stop-color="#5B5CF0"/><stop offset=".6" stop-color="#2E8BF0"/>
        <stop offset=".82" stop-color="#22C3EE"/><stop offset="1" stop-color="#2EE6C5"/></linearGradient></defs>
      <g fill="url(#scg)">
        <path d="M347.71 87.02A202 202 0 0 1 457.72 277.57A26 26 0 0 1 405.79 274.85A150 150 0 0 0 324.1 133.35A26 26 0 0 1 347.71 87.02Z"/>
        <path d="M366.02 436.41A202 202 0 0 1 145.98 436.41A26 26 0 0 1 174.3 392.8A150 150 0 0 0 337.7 392.8A26 26 0 0 1 366.02 436.41Z"/>
        <path d="M54.28 277.57A202 202 0 0 1 164.29 87.02A26 26 0 0 1 187.9 133.35A150 150 0 0 0 106.21 274.85A26 26 0 0 1 54.28 277.57Z"/>
        <circle cx="256" cy="91" r="50"/><circle cx="408.42" cy="355" r="50"/><circle cx="103.58" cy="355" r="50"/>
        <rect x="161" y="212" width="46" height="110" rx="23"/><rect x="233" y="159" width="46" height="216" rx="23"/>
        <rect x="305" y="212" width="46" height="110" rx="23"/>
      </g>
    </svg>`

  const host = document.createElement('div')
  host.id = 'spectracast-floating'
  host.style.cssText = `position:fixed;z-index:2147483646;display:none;width:${SIZE}px;height:${SIZE}px;left:0;top:0;`
  const root = host.attachShadow({ mode: 'closed' })
  root.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      button { all: unset; box-sizing: border-box; cursor: pointer; }
      button:focus-visible, input:focus-visible { outline: 2px solid #3FB58E; outline-offset: 3px; }
      .wrap { position: relative; width: ${SIZE}px; height: ${SIZE}px; font: 600 13px/1.2 Inter, 'Segoe UI', Roboto, Arial, sans-serif; color: #EEEDF6; }

      /* Botão principal: círculo escuro com aro no gradiente da marca */
      .fab { position: absolute; inset: 0; border-radius: 50%; display: grid; place-items: center; touch-action: none;
        background: radial-gradient(120% 120% at 30% 20%, #1D1A2B 0%, #0B0A12 70%);
        box-shadow: 0 6px 18px rgba(0,0,0,.45), 0 0 0 1px rgba(255,255,255,.04) inset;
        opacity: .78; transition: opacity .18s, transform .18s, box-shadow .18s; }
      .fab::before { content: ''; position: absolute; inset: 0; border-radius: 50%; padding: 1.5px;
        background: conic-gradient(from 200deg, #9B4DF5, #5B5CF0, #2E8BF0, #22C3EE, #2EE6C5, #9B4DF5);
        -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; }
      .wrap.expanded .fab, .wrap.open .fab, .fab:focus-visible { opacity: 1; transform: scale(1.06);
        box-shadow: 0 8px 24px rgba(0,0,0,.5), 0 0 18px rgba(46,230,197,.28); }
      .wrap.dragging .fab { cursor: grabbing; opacity: 1; transform: scale(1.1); transition: opacity .18s, box-shadow .18s; }
      .logo { width: 24px; height: 24px; transition: transform .2s, opacity .2s; }
      .state { position: absolute; width: 22px; height: 22px; opacity: 0; transform: scale(.6); transition: opacity .2s, transform .2s; }

      .fab.busy::before { animation: spin 1s linear infinite; }
      .fab.ok::before { background: #3FB58E; }
      .fab.err::before { background: #F0457A; }
      .fab.ok .logo, .fab.err .logo { opacity: 0; transform: scale(.6); }
      .fab.ok .state.ok, .fab.err .state.err { opacity: 1; transform: none; }
      @keyframes spin { to { transform: rotate(360deg); } }

      /* Botões pequenos e etiqueta: aparecem do lado de dentro da tela ao passar o mouse */
      .tools { position: absolute; top: 50%; display: flex; align-items: center; gap: 6px; transform: translateY(-50%);
        opacity: 0; pointer-events: none; transition: opacity .16s, transform .16s; }
      /* o espaço de 8px fica dentro de .tools: o mouse passa do botão para eles sem perder o hover */
      .side-l .tools { right: 100%; padding-right: 8px; flex-direction: row-reverse; }
      .side-r .tools { left: 100%; padding-left: 8px; }
      .wrap.expanded:not(.dragging) .tools, .wrap.open .tools, .wrap.status .tools, .wrap:has(:focus-visible) .tools { opacity: 1; pointer-events: auto; }
      .mini { width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; color: #A09CB8;
        background: #15131F; border: 1px solid #2A2740; box-shadow: 0 4px 12px rgba(0,0,0,.4); transition: color .12s, background .12s, border-color .12s; }
      .mini:hover, .mini[aria-expanded="true"] { color: #EEEDF6; background: #1D1A2B; border-color: #3a3658; }
      .mini[aria-expanded="true"] { color: #2EE6C5; border-color: rgba(46,230,197,.45); }
      .pill { height: 30px; padding: 0 12px; border-radius: 999px; display: flex; align-items: center; white-space: nowrap;
        max-width: 240px; overflow: hidden; text-overflow: ellipsis; background: rgba(21,19,31,.94); border: 1px solid #2A2740;
        box-shadow: 0 4px 12px rgba(0,0,0,.4); color: #EEEDF6;
        font: 600 12.5px/1 Inter, 'Segoe UI', Roboto, Arial, sans-serif; letter-spacing: 0; }
      /* Duas ações, uma embaixo da outra: "Tocar no site" e "Tocar no app" (app para Windows). */
      .pills { position: relative; display: flex; }
      .side-l .pills { justify-content: flex-end; }
      .pill.main, .pill.app { cursor: pointer; transition: color .12s, background .12s, border-color .12s; }
      .pill.app { position: absolute; top: calc(100% + 6px); }
      /* ponte invisível entre as duas etiquetas: o mouse passa de uma para a outra sem sair do botão */
      .pill.app::before { content: ''; position: absolute; left: 0; right: 0; top: -8px; height: 8px; }
      .side-l .pill.app { right: 0; }
      .side-r .pill.app { left: 0; }
      .pill.main:hover:not(.ok):not(.err), .pill.app:hover { color: #2EE6C5; border-color: rgba(46,230,197,.45); background: #1D1A2B; }
      .wrap.status .pill.app { display: none; }
      .pill span { overflow: hidden; text-overflow: ellipsis; }
      .wrap.status .mini { display: none; }
      .pill.ok { color: #55C9A2; border-color: rgba(63,181,142,.45); }
      .pill.err { color: #ff7d9f; border-color: rgba(240,69,122,.45); }

      /* Menu de playlists */
      .menu { position: fixed; width: 300px; max-height: 380px; display: none; flex-direction: column; overflow: hidden;
        background: #15131F; border: 1px solid #2A2740; border-radius: 16px; box-shadow: 0 18px 48px rgba(0,0,0,.55); }
      .menu.open { display: flex; }
      .menu header { padding: 12px 14px 10px; color: #A09CB8; font-size: 11px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
        border-bottom: 1px solid #2A2740; display: flex; justify-content: space-between; gap: 8px; }
      .menu header span:last-child { text-transform: none; letter-spacing: 0; font-weight: 600; color: #6B6785; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .list { overflow-y: auto; padding: 6px; scrollbar-width: thin; scrollbar-color: #2A2740 transparent; }
      .item { display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 10px; border-radius: 10px; }
      .item:hover { background: #1D1A2B; }
      .item b { flex: none; width: 28px; height: 28px; border-radius: 50%; display: grid; place-items: center; color: #072219; font-size: 12px;
        background: linear-gradient(135deg, #22C3EE, #2EE6C5); }
      .item span { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .item small { color: #6B6785; font-size: 11px; font-weight: 500; }
      .item.queue b { background: #3FB58E; }
      .sep { height: 1px; margin: 4px 8px; background: #2A2740; }
      .note { padding: 10px 12px; color: #A09CB8; font-weight: 500; line-height: 1.45; }
      .note button { color: #55C9A2; text-decoration: underline; }
      .new { display: flex; gap: 6px; padding: 10px; border-top: 1px solid #2A2740; }
      .new input { flex: 1; min-width: 0; height: 34px; padding: 0 14px; border-radius: 999px; background: #0B0A12; border: 1px solid #2A2740;
        color: #EEEDF6; font: 500 13px Inter, 'Segoe UI', Roboto, Arial, sans-serif; outline: none; }
      .new input:focus { border-color: #3FB58E; }
      .new button { padding: 0 16px; height: 34px; border-radius: 999px; display: grid; place-items: center; background: #3FB58E; color: #072219; font-weight: 700; }
      .new button:hover:not([disabled]) { background: #55C9A2; }
      .new button[disabled] { opacity: .45; cursor: default; }
      .loading { padding: 12px; color: #6B6785; font-weight: 500; }
    </style>
    <div class="wrap side-l">
      <button class="fab" aria-label="Tocar na sala do SpectraCast">
        ${SYMBOL}
        <svg class="state ok" viewBox="0 0 24 24" fill="none" stroke="#3FB58E" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
        <svg class="state err" viewBox="0 0 24 24" fill="none" stroke="#F0457A" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 7v6M12 17h.01"/></svg>
      </button>
      <div class="tools">
        <div class="pills">
          <button class="pill main" title="Manda a música para a sala aberta no site"><span class="label">Tocar no site</span></button>
          <button class="pill app" title="Manda a música para a sala aberta no app SpectraCast para Windows"><span>Tocar no app</span></button>
        </div>
        <button class="mini more" title="Salvar numa playlist" aria-label="Salvar numa playlist" aria-haspopup="menu" aria-expanded="false">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h11M4 12h11M4 18h7M18 15v6M15 18h6"/></svg>
        </button>
        <button class="mini close" title="Esconder nesta página" aria-label="Esconder botão do SpectraCast">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>
      <div class="menu" role="menu"></div>
    </div>`
  document.documentElement.appendChild(host)

  const wrap = root.querySelector('.wrap')
  const fab = root.querySelector('.fab')
  const pill = root.querySelector('.pill.main')
  const appPill = root.querySelector('.pill.app')
  const label = root.querySelector('.label')
  const closeBtn = root.querySelector('.close')
  const moreBtn = root.querySelector('.more')
  const menu = root.querySelector('.menu')
  let hidden = false
  let busy = false
  let menuOpen = false
  let resetTimer = null

  // ---- posição livre (arrastar para qualquer lugar) ----------------------------

  let pos = null // { x, y } em fração da janela

  function clampPx(cx, cy) {
    const half = SIZE / 2
    return {
      cx: Math.max(MARGIN + half, Math.min(innerWidth - MARGIN - half, cx)),
      cy: Math.max(MARGIN + half, Math.min(innerHeight - MARGIN - half, cy)),
    }
  }

  function applyPos() {
    const p = pos || { x: 1, y: 1 } // padrão: canto inferior direito
    const def = !pos
    let cx = p.x * innerWidth
    let cy = p.y * innerHeight
    if (def) {
      cx = innerWidth - 28 - SIZE / 2
      cy = innerHeight - 120 - SIZE / 2
    }
    const c = clampPx(cx, cy)
    host.style.left = `${Math.round(c.cx - SIZE / 2)}px`
    host.style.top = `${Math.round(c.cy - SIZE / 2)}px`
    // Etiqueta, botões pequenos e menu abrem para o lado de dentro da tela.
    const right = c.cx > innerWidth / 2
    wrap.classList.toggle('side-l', right)
    wrap.classList.toggle('side-r', !right)
    if (menuOpen) placeMenu()
  }

  try {
    chrome.storage.local.get(POS_KEY).then((r) => {
      const p = r && r[POS_KEY]
      if (p && typeof p.x === 'number' && typeof p.y === 'number') pos = p
      applyPos()
    })
  } catch {
    /* extensão recarregada: usa a posição padrão */
  }
  applyPos()
  window.addEventListener('resize', applyPos)

  let drag = null
  let suppressClick = false

  fab.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return
    const r = host.getBoundingClientRect()
    drag = { id: e.pointerId, sx: e.clientX, sy: e.clientY, ox: e.clientX - (r.left + SIZE / 2), oy: e.clientY - (r.top + SIZE / 2), moved: false }
    fab.setPointerCapture(e.pointerId)
  })

  fab.addEventListener('pointermove', (e) => {
    if (!drag || e.pointerId !== drag.id) return
    if (!drag.moved && Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) < DRAG_THRESHOLD) return
    if (!drag.moved) {
      drag.moved = true
      wrap.classList.add('dragging')
      closeMenu()
    }
    const c = clampPx(e.clientX - drag.ox, e.clientY - drag.oy)
    pos = { x: c.cx / innerWidth, y: c.cy / innerHeight }
    applyPos()
  })

  function endDrag(e) {
    if (!drag || e.pointerId !== drag.id) return
    const moved = drag.moved
    drag = null
    wrap.classList.remove('dragging')
    if (moved) {
      suppressClick = true
      setTimeout(() => (suppressClick = false), 0)
      try {
        chrome.storage.local.set({ [POS_KEY]: pos })
      } catch {
        /* ignora */
      }
    }
  }
  fab.addEventListener('pointerup', endDrag)
  fab.addEventListener('pointercancel', endDrag)

  // Mesma posição em todas as abas do YouTube.
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes[POS_KEY] || drag) return
      const p = changes[POS_KEY].newValue
      if (p && typeof p.x === 'number') {
        pos = p
        applyPos()
      }
    })
  } catch {
    /* ignora */
  }

  // ---- mostrar/esconder as ações ------------------------------------------------
  // Controlado por JS (não por :hover) com um atraso ao sair: o mouse pode passar pelos
  // espaços entre o botão e as etiquetas sem que elas sumam.
  let hideTimer = null
  function expand() {
    clearTimeout(hideTimer)
    wrap.classList.add('expanded')
  }
  function collapseSoon(ms = 700) {
    clearTimeout(hideTimer)
    hideTimer = setTimeout(() => wrap.classList.remove('expanded'), ms)
  }
  wrap.addEventListener('pointerenter', expand)
  wrap.addEventListener('pointermove', expand)
  wrap.addEventListener('pointerleave', () => collapseSoon())

  // ---- estado e envio -------------------------------------------------------------

  function idleLabel(t) {
    return t && t.kind === 'playlist' ? 'Tocar playlist no site' : 'Tocar no site'
  }

  /** Mostra um aviso curto ao lado do botão (cls: '', 'ok' ou 'err'). */
  function setStatus(text, cls) {
    label.textContent = text
    pill.classList.remove('ok', 'err')
    fab.classList.remove('ok', 'err', 'busy')
    wrap.classList.add('status')
    if (cls === 'busy') fab.classList.add('busy')
    else if (cls) {
      pill.classList.add(cls)
      fab.classList.add(cls)
    }
  }

  function clearStatus() {
    wrap.classList.remove('status')
    pill.classList.remove('ok', 'err')
    fab.classList.remove('ok', 'err', 'busy')
  }

  function refresh() {
    const t = hidden ? null : currentTarget()
    host.style.display = t ? 'block' : 'none'
    if (t && !busy && !wrap.classList.contains('status')) {
      label.textContent = idleLabel(t)
      fab.title = `Pôr na fila da sua sala: ${t.title}\n(arraste para mudar de lugar)`
    }
  }

  function finish(ms) {
    busy = false
    clearTimeout(resetTimer)
    resetTimer = setTimeout(() => {
      clearStatus()
      refresh()
    }, ms)
  }

  // Clique no botão redondo ou na etiqueta "Tocar no site": manda para a sala do site.
  fab.addEventListener('click', () => {
    if (!suppressClick) sendToSite()
  })
  pill.addEventListener('click', (e) => {
    e.stopPropagation()
    if (!wrap.classList.contains('status')) sendToSite()
  })

  async function sendToSite() {
    const t = currentTarget()
    if (!t || busy) return
    busy = true
    clearTimeout(resetTimer)
    closeMenu()
    setStatus('Enviando…', 'busy')
    // Copia o link (útil para colar em outro lugar).
    try {
      await navigator.clipboard.writeText(t.url)
    } catch {
      /* sem permissão de área de transferência: segue */
    }
    // Evita ouvir em dobro: pausa o vídeo desta aba (e segura a pausa).
    pauseHere()
    try {
      const res = await chrome.runtime.sendMessage({ type: 'ECHOROOM_SEND', url: t.url, title: t.title })
      if (res && res.ok) setStatus('Enviado para a sala', 'ok')
      else setStatus('Não foi possível enviar', 'err')
    } catch {
      setStatus('Recarregue a página e tente de novo', 'err')
    }
    finish(2500)
  }

  // "Tocar no app": abre o app SpectraCast para Windows pelo endereço spectracast://
  // (o Chrome pergunta uma vez se pode abrir o app). O app põe a música na sala aberta nele.
  appPill.addEventListener('click', (e) => {
    e.stopPropagation()
    if (suppressClick || busy) return
    const t = currentTarget()
    if (!t) return
    closeMenu()
    const u = new URL('spectracast://add')
    u.searchParams.set('url', t.url)
    if (t.title) u.searchParams.set('title', String(t.title).slice(0, 200))
    const a = document.createElement('a')
    a.href = u.toString()
    a.rel = 'noopener'
    a.style.display = 'none'
    document.body.appendChild(a)
    a.click()
    a.remove()
    pauseHere()
    setStatus('Abrindo no app…', 'ok')
    finish(2500)
  })

  /**
   * Pausa o YouTube desta aba. Por alguns segundos, se o player tentar voltar
   * a tocar sozinho (troca de foco, autoplay, próxima da fila), pausa de novo.
   */
  let holdUntil = 0
  function pauseVideos() {
    document.querySelectorAll('video').forEach((v) => {
      try {
        if (!v.paused) v.pause()
      } catch {
        /* ignora */
      }
    })
  }
  function pauseHere() {
    holdUntil = Date.now() + 8000
    pauseVideos()
  }
  document.addEventListener(
    'play',
    (e) => {
      if (Date.now() < holdUntil && e.target instanceof HTMLVideoElement) e.target.pause()
    },
    true,
  )
  // O usuário pode dar play de novo de propósito: libera a pausa ao clicar no player.
  document.addEventListener(
    'pointerdown',
    (e) => {
      if (e.target instanceof Element && e.target.closest('#movie_player, ytmusic-player, video')) holdUntil = 0
    },
    true,
  )
  document.addEventListener('keydown', () => (holdUntil = 0), true)

  closeBtn.addEventListener('click', () => {
    hidden = true
    closeMenu()
    refresh()
  })

  // ---- menu de playlists ------------------------------------------------------

  const esc = (t) => String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

  function placeMenu() {
    const r = host.getBoundingClientRect()
    const w = 300
    const h = Math.min(380, menu.offsetHeight || 380)
    const right = r.left + SIZE / 2 > innerWidth / 2
    let left = right ? r.right - w : r.left
    left = Math.max(MARGIN, Math.min(innerWidth - w - MARGIN, left))
    // Abre para cima se houver espaço, senão para baixo.
    let top = r.top - h - 10
    if (top < MARGIN) top = r.bottom + 10
    top = Math.max(MARGIN, Math.min(innerHeight - h - MARGIN, top))
    menu.style.left = `${Math.round(left)}px`
    menu.style.top = `${Math.round(top)}px`
  }

  function closeMenu() {
    menuOpen = false
    menu.classList.remove('open')
    wrap.classList.remove('open')
    moreBtn.setAttribute('aria-expanded', 'false')
  }

  function renderMenu(state) {
    const t = currentTarget()
    const head = `<header><span>Salvar em</span><span>${state.user ? esc(state.user) : ''}</span></header>`
    const queue = `<button class="item queue" role="menuitem" data-act="queue"><b>▶</b><span>Fila da sala</span><small>tocar agora</small></button><div class="sep"></div>`
    let body = ''
    if (state.loading && !state.playlists) body = '<div class="loading">Carregando suas playlists…</div>'
    else if (state.login) body = '<div class="note">Para ter playlists, entre na sua conta do SpectraCast. <button data-act="login">Entrar</button></div>'
    else if (state.error && !state.playlists) body = `<div class="note">${esc(state.error)}</div>`
    else if (state.playlists && !state.playlists.length) body = '<div class="note">Você ainda não tem playlists. Crie uma abaixo.</div>'
    else
      body = (state.playlists || [])
        .map((p) => `<button class="item" role="menuitem" data-id="${esc(p.id)}"><b>♪</b><span>${esc(p.name)}</span><small>${Number(p.count) || 0}</small></button>`)
        .join('')
    const form = state.login
      ? ''
      : `<form class="new"><input maxlength="60" placeholder="Nova playlist" title="Cria uma playlist sua já com ${t && t.kind === 'playlist' ? 'esta lista' : 'esta música'}" aria-label="Nome da nova playlist"><button type="submit" disabled>Criar</button></form>`
    menu.innerHTML = head + `<div class="list">${queue}${body}</div>` + form
    const input = menu.querySelector('.new input')
    const create = menu.querySelector('.new button')
    if (input) input.addEventListener('input', () => (create.disabled = !input.value.trim()))
    if (menuOpen) placeMenu()
  }

  let menuState = {}
  async function openMenu() {
    menuOpen = true
    wrap.classList.add('open')
    moreBtn.setAttribute('aria-expanded', 'true')
    menu.classList.add('open')
    const cached = await chrome.storage.local.get(['playlists', 'playlistsUser'])
    menuState = { playlists: cached.playlists || null, user: cached.playlistsUser || '', loading: true }
    renderMenu(menuState)
    try {
      const res = await chrome.runtime.sendMessage({ type: 'ECHOROOM_PLAYLISTS' })
      if (!menuOpen) return
      if (res && res.ok) menuState = { playlists: res.playlists, user: res.user }
      else if (res && res.error === 'login') menuState = { login: true }
      else menuState = { ...menuState, loading: false, error: (res && res.error) || 'Não foi possível ler as playlists.' }
    } catch {
      menuState = { ...menuState, loading: false, error: 'Recarregue a página e tente de novo.' }
    }
    if (menuOpen) renderMenu(menuState)
  }

  moreBtn.addEventListener('click', () => (menuOpen ? closeMenu() : openMenu()))

  async function saveTo(target) {
    const t = currentTarget()
    if (!t) return
    closeMenu()
    busy = true
    clearTimeout(resetTimer)
    setStatus('Salvando…', 'busy')
    try {
      const res = await chrome.runtime.sendMessage({ type: 'ECHOROOM_SAVE', url: t.url, title: t.title, ...target })
      if (res && res.ok) setStatus(`Salvo em ${res.name}`, 'ok')
      else if (res && res.error === 'login') {
        // Sem login: leva direto para a tela de entrar.
        setStatus('Entre na sua conta para salvar', 'err')
        chrome.runtime.sendMessage({ type: 'ECHOROOM_OPEN_LOGIN' })
      } else setStatus((res && res.error) || 'Não foi possível salvar', 'err')
    } catch {
      setStatus('Recarregue a página e tente de novo', 'err')
    }
    finish(3000)
  }

  menu.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act], [data-id]')
    if (!el) return
    if (el.dataset.act === 'queue') {
      closeMenu()
      fab.click()
    } else if (el.dataset.act === 'login') {
      closeMenu()
      chrome.runtime.sendMessage({ type: 'ECHOROOM_OPEN_LOGIN' })
    } else if (el.dataset.id) {
      saveTo({ playlistId: el.dataset.id })
    }
  })
  menu.addEventListener('submit', (e) => {
    e.preventDefault()
    const input = menu.querySelector('.new input')
    const name = input && input.value.trim()
    if (name) saveTo({ newName: name })
  })
  // Teclas digitadas no campo não podem virar atalhos do YouTube (k, j, f…).
  menu.addEventListener('keydown', (e) => {
    e.stopPropagation()
    if (e.key === 'Escape') closeMenu()
  })
  // Clique fora fecha o menu.
  document.addEventListener(
    'pointerdown',
    (e) => {
      if (menuOpen && !e.composedPath().includes(host)) closeMenu()
    },
    true,
  )
  document.addEventListener('keydown', (e) => {
    if (menuOpen && e.key === 'Escape') closeMenu()
  })

  // Em tela cheia o botão some (volta ao sair).
  document.addEventListener('fullscreenchange', () => {
    host.style.visibility = document.fullscreenElement ? 'hidden' : ''
  })

  // O YouTube é uma SPA: acompanha trocas de página.
  let lastHref = ''
  const check = () => {
    if (location.href !== lastHref) {
      lastHref = location.href
      hidden = false
      closeMenu()
    }
    refresh()
  }
  window.addEventListener('yt-navigate-finish', check)
  window.addEventListener('popstate', check)
  setInterval(check, 1500)
  check()
})()
