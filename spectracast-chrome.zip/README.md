# Extensão SpectraCast para Chrome

Coloca um **botão redondo e discreto** nas páginas do YouTube (vídeos, shorts e
playlists). Ele fica meio transparente até você passar o mouse, e pode ser
**arrastado para qualquer lugar da aba** (a posição fica salva e vale para todas as
abas do YouTube).

Ao clicar no botão:

1. copia o link da música,
2. pausa o vídeo daquela aba (e segura a pausa por alguns segundos, para não tocar em dobro),
3. **abre a sala do SpectraCast na frente** e manda a música:
   - se já existe uma aba da sala, muda para ela e a música entra na fila;
   - senão, abre `www.spectracast.com.br/sala/` numa aba nova, que entra na
     **última sala usada** neste navegador e adiciona a música.

Passando o mouse sobre o botão aparecem as ações (elas ficam abertas enquanto o mouse
estiver no botão ou nelas, e somem 0,7 s depois que ele sai):

- **Tocar no site**: o mesmo que clicar no botão redondo.
- **Tocar no app**: abre o app SpectraCast para Windows pelo link `spectracast://add`
  (o Chrome pergunta uma vez se pode abrir o app) e a música entra na sala aberta nele.

E dois botões menores:

- **Playlists** (ícone de lista com +): salva a música (ou a playlist do YouTube
  inteira) numa playlist sua, ou cria uma nova ali mesmo. Precisa estar logado na
  sala. Se nenhuma aba da sala estiver aberta, a extensão abre uma em segundo plano e
  fecha depois.
- **×**: esconde o botão nesta página (ele volta ao abrir outro vídeo).

## Instalar

1. Baixe `spectracast-chrome.zip` em www.spectracast.com.br (seção “Extensão para Chrome”).
2. Clique com o botão direito no arquivo → **Extrair tudo**, e guarde a pasta num lugar fixo.
3. Abra `chrome://extensions`.
4. Ligue **Modo do desenvolvedor** (canto superior direito).
5. Clique em **Carregar sem compactação** e escolha a pasta extraída.
6. Recarregue as abas do YouTube que já estavam abertas.

Se tinha a extensão antiga do EchoRoom, remova-a em `chrome://extensions` para não
ficar com dois botões.

## Atualizar

Baixe o zip de novo, substitua os arquivos da pasta e clique em recarregar (↻) na
extensão em `chrome://extensions`. Depois recarregue as abas do YouTube.

## Endereço do site

Está em `background.js` (`SITE`) e no `manifest.json` (`host_permissions` e o
segundo `matches`). Se a sala mudar de endereço, altere os três.

As mensagens trocadas com o site ainda usam os nomes `ECHOROOM_*` /
`echoroom-extension` / `<html data-echoroom>`, porque é isso que a sala (que veio do
EchoRoom) entende — ver `web/src/services/externalAdd.ts` e `extensionBridge.ts`.

## Publicação

O workflow **Página de download** (`.github/workflows/pages.yml`) compacta esta pasta
em `spectracast-chrome.zip` na raiz do site a cada mudança no `main`.
